
// Toggle Theme
document.getElementById("toggle-theme").addEventListener("click", () => {
  document.body.classList.toggle("dark-theme");
  document.body.classList.toggle("light-theme");
});

// Basic Arithmetic
function calculateBasic() {
  const n1 = parseFloat(document.getElementById("num1").value);
  const n2 = parseFloat(document.getElementById("num2").value);
  const op = document.getElementById("operation").value;
  let result = "Invalid";

  switch(op) {
    case "+": result = n1 + n2; break;
    case "-": result = n1 - n2; break;
    case "*": result = n1 * n2; break;
    case "/": result = n2 !== 0 ? n1 / n2 : "Error (divide by 0)"; break;
  }

  document.getElementById("basic-result").innerText = "Result: " + result;
}

// Geometric Calculations
function calcCircleArea() {
  const r = parseFloat(document.getElementById("circle-radius").value);
  const area = Math.PI * r * r;
  document.getElementById("circle-result").innerText = "Area: " + area.toFixed(2);
}

function calcRectangleArea() {
  const l = parseFloat(document.getElementById("rect-length").value);
  const w = parseFloat(document.getElementById("rect-width").value);
  const area = l * w;
  document.getElementById("rect-result").innerText = "Area: " + area.toFixed(2);
}

function calcCubeVolume() {
  const s = parseFloat(document.getElementById("cube-side").value);
  const volume = s ** 3;
  document.getElementById("cube-result").innerText = "Volume: " + volume.toFixed(2);
}

function calcSphereVolume() {
  const r = parseFloat(document.getElementById("sphere-radius").value);
  const volume = (4 / 3) * Math.PI * r ** 3;
  document.getElementById("sphere-result").innerText = "Volume: " + volume.toFixed(2);
}
